"""
Impact Radar — Enterprise Software Change Impact Analysis Platform
------------------------------------------------------------------
Run with:  streamlit run impact_radar.py

What changed vs. the original mockup:
  - The dependency graph is REAL. Picking a changed module runs a reverse
    dependency traversal, computes the blast radius (direct vs. indirect),
    and renders a live, color-coded graph.
  - Risk, impacted counts, and affected modules are COMPUTED from that
    traversal, not hardcoded.
  - Enterprise dark theme (Linear/Vercel-style): sharp, restrained, one
    accent — instead of consumer glassmorphism.
"""

from collections import deque, defaultdict
import streamlit as st

# ---------------------------------------------------------------------------
# Page config
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="Impact Radar",
    page_icon="◎",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------------
# Domain model
# A module maps to the list of modules it DEPENDS ON.
# "Changing X impacts everything that (transitively) depends on X."
# ---------------------------------------------------------------------------
PROJECTS = {
    "Student Enrollment System": {
        "Student": [],
        "Course": [],
        "Enrollment": ["Student", "Course"],
        "Assignment": ["Course"],
        "Grade": ["Enrollment", "Assignment"],
        "Report": ["Grade", "Enrollment"],
        "Notification": ["Enrollment", "Grade"],
        "Transcript": ["Grade"],
    },
    "Hospital Management System": {
        "Patient": [],
        "Doctor": [],
        "Appointment": ["Patient", "Doctor"],
        "Prescription": ["Appointment", "Patient"],
        "Pharmacy": ["Prescription"],
        "Billing": ["Appointment", "Prescription"],
        "Insurance": ["Billing", "Patient"],
        "Analytics": ["Billing", "Appointment"],
    },
    "Library Management System": {
        "Member": [],
        "Book": [],
        "Catalog": ["Book"],
        "Loan": ["Member", "Book"],
        "Fine": ["Loan"],
        "Reservation": ["Member", "Catalog"],
        "Notification": ["Loan", "Reservation", "Fine"],
    },
}

# ---------------------------------------------------------------------------
# Impact engine
# ---------------------------------------------------------------------------
def reverse_dependents(modules: dict) -> dict:
    """For each module, the set of modules that DIRECTLY depend on it."""
    dependents = defaultdict(set)
    for module, deps in modules.items():
        for dep in deps:
            dependents[dep].add(module)
    return dependents


def compute_impact(modules: dict, changed: str):
    """Reverse-BFS from the changed module to find its blast radius."""
    dependents = reverse_dependents(modules)
    direct = set(dependents.get(changed, set()))

    all_impacted, queue = set(), deque([changed])
    while queue:
        current = queue.popleft()
        for dep in dependents.get(current, set()):
            if dep not in all_impacted:
                all_impacted.add(dep)
                queue.append(dep)

    indirect = all_impacted - direct
    return direct, indirect, all_impacted


def assess_risk(all_impacted: set, total_modules: int):
    """Risk derived from blast radius as a share of the system."""
    ratio = len(all_impacted) / max(total_modules - 1, 1)
    if ratio >= 0.5:
        return "HIGH", "#ef4444", ratio
    if ratio >= 0.25:
        return "MEDIUM", "#f59e0b", ratio
    return "LOW", "#22c55e", ratio


def build_dot(modules: dict, changed: str, direct: set, indirect: set) -> str:
    """Construct DOT source so Streamlit can render the live graph."""
    lines = [
        "digraph G {",
        "  rankdir=LR;",
        '  bgcolor="transparent";',
        '  node [shape=box style="rounded,filled" fontname="Inter"'
        ' fontsize=11 penwidth=1.4 margin="0.18,0.10"];',
        '  edge [color="#3f4a5f" arrowsize=0.7 penwidth=1.1];',
    ]
    for module in modules:
        if module == changed:
            fill, font, border = "#6366f1", "#ffffff", "#a5b4fc"
        elif module in direct:
            fill, font, border = "#ef4444", "#ffffff", "#fca5a5"
        elif module in indirect:
            fill, font, border = "#7f1d1d", "#fecaca", "#dc2626"
        else:
            fill, font, border = "#1b2434", "#7b8aa3", "#2b364a"
        lines.append(
            f'  "{module}" [fillcolor="{fill}" fontcolor="{font}" color="{border}"];'
        )
    for module, deps in modules.items():
        for dep in deps:
            # Impact flows from a dependency to the modules that rely on it.
            lines.append(f'  "{dep}" -> "{module}";')
    lines.append("}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Styling — enterprise dark, single indigo accent, no glass
# ---------------------------------------------------------------------------
st.markdown(
    """
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root {
    --bg:        #0b0f17;
    --panel:     #111726;
    --panel-2:   #0e1421;
    --border:    #1f2937;
    --text:      #e5e9f0;
    --muted:     #7b8aa3;
    --accent:    #6366f1;
}

html, body, [class*="css"] { font-family: 'Inter', sans-serif; }
.stApp { background: var(--bg); }
section[data-testid="stSidebar"] {
    background: var(--panel-2);
    border-right: 1px solid var(--border);
}
.block-container { padding-top: 2.2rem; padding-bottom: 3rem; }

/* Headings */
.ir-title { font-size: 30px; font-weight: 700; color: var(--text); letter-spacing: -0.5px; }
.ir-sub   { color: var(--muted); font-size: 14px; margin-bottom: 22px; }
.ir-eyebrow { color: var(--accent); font-size: 12px; font-weight: 600;
              letter-spacing: 1.2px; text-transform: uppercase; margin-bottom: 4px; }

/* Cards */
.card {
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 18px 20px;
}
.card h4 { color: var(--text); font-size: 14px; font-weight: 600; margin: 0 0 12px 0; }

/* Compact metric strip */
.metric { background: var(--panel); border: 1px solid var(--border);
          border-radius: 12px; padding: 14px 18px; }
.metric .label { color: var(--muted); font-size: 12px; font-weight: 500;
                 text-transform: uppercase; letter-spacing: 0.6px; }
.metric .value { color: var(--text); font-size: 26px; font-weight: 700; margin-top: 2px; }

/* Risk badge */
.risk-badge { display:inline-block; padding: 6px 14px; border-radius: 8px;
              font-weight: 700; font-size: 18px; letter-spacing: 0.5px; }

/* Affected list rows */
.row { display:flex; justify-content:space-between; align-items:center;
       padding: 9px 0; border-bottom: 1px solid var(--border); }
.row:last-child { border-bottom: none; }
.row .name { color: var(--text); font-size: 13px; font-weight: 500; }
.tag { font-size: 11px; font-weight: 600; padding: 3px 9px; border-radius: 6px; }
.tag-direct   { background: rgba(239,68,68,0.15);  color: #f87171; }
.tag-indirect { background: rgba(245,158,11,0.15); color: #fbbf24; }

/* Native widget polish */
.stButton > button {
    background: var(--accent); color: #fff; border: none; border-radius: 9px;
    font-weight: 600; padding: 0.5rem 1rem;
}
.stButton > button:hover { background: #4f52d6; color: #fff; }
hr { border-color: var(--border); }
</style>
""",
    unsafe_allow_html=True,
)

# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
with st.sidebar:
    st.markdown("### ◎ Impact Radar")
    st.caption("Change Impact Analysis")
    st.markdown("---")
    page = st.radio(
        "Navigation",
        ["Dashboard", "Projects", "Impact Analysis", "Reports"],
        label_visibility="collapsed",
    )

# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------
if page == "Dashboard":
    st.markdown('<div class="ir-eyebrow">Change Impact Analysis</div>', unsafe_allow_html=True)
    st.markdown('<div class="ir-title">Impact Radar</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="ir-sub">Trace how a single module change ripples through '
        "your system before you ship it.</div>",
        unsafe_allow_html=True,
    )

    # --- Controls ---
    ctrl1, ctrl2, ctrl3 = st.columns([2, 2, 1])
    with ctrl1:
        project = st.selectbox("Project", list(PROJECTS.keys()))
    modules = PROJECTS[project]
    with ctrl2:
        changed = st.selectbox("Changed module", list(modules.keys()))
    with ctrl3:
        st.markdown("<div style='height:28px'></div>", unsafe_allow_html=True)
        analyze = st.button("Analyze impact", use_container_width=True)

    # Persist last analysis so the panels stay in sync on rerun
    if analyze or "impact" not in st.session_state:
        direct, indirect, all_impacted = compute_impact(modules, changed)
        st.session_state.impact = (project, changed, direct, indirect, all_impacted)

    project, changed, direct, indirect, all_impacted = st.session_state.impact
    modules = PROJECTS[project]
    level, color, ratio = assess_risk(all_impacted, len(modules))

    st.markdown("<br>", unsafe_allow_html=True)
    left, right = st.columns([3, 1.15])

    # --- Hero: live dependency graph ---
    with left:
        st.markdown('<div class="card"><h4>Dependency graph</h4>', unsafe_allow_html=True)
        st.graphviz_chart(build_dot(modules, changed, direct, indirect), use_container_width=True)
        st.markdown(
            '<div style="color:var(--muted);font-size:12px;margin-top:6px;">'
            '<span style="color:#a5b4fc;">●</span> changed &nbsp;'
            '<span style="color:#ef4444;">●</span> direct impact &nbsp;'
            '<span style="color:#dc2626;">●</span> indirect impact &nbsp;'
            '<span style="color:#7b8aa3;">●</span> unaffected</div></div>',
            unsafe_allow_html=True,
        )

    # --- Risk + affected modules ---
    with right:
        st.markdown(
            f'<div class="card"><h4>Risk assessment</h4>'
            f'<span class="risk-badge" style="background:{color}22;color:{color};">{level}</span>'
            f'<div style="color:var(--muted);font-size:13px;margin-top:14px;">'
            f"Blast radius: {len(all_impacted)} of {len(modules) - 1} modules "
            f"({ratio*100:.0f}%)</div></div>",
            unsafe_allow_html=True,
        )
        st.markdown("<br>", unsafe_allow_html=True)

        rows = "".join(
            f'<div class="row"><span class="name">{m}</span>'
            f'<span class="tag tag-direct">Direct</span></div>'
            for m in sorted(direct)
        ) + "".join(
            f'<div class="row"><span class="name">{m}</span>'
            f'<span class="tag tag-indirect">Indirect</span></div>'
            for m in sorted(indirect)
        )
        if not rows:
            rows = ('<div style="color:var(--muted);font-size:13px;">'
                    "No downstream modules affected. Safe to change.</div>")
        st.markdown(f'<div class="card"><h4>Affected modules</h4>{rows}</div>',
                    unsafe_allow_html=True)

    # --- Compact metric strip ---
    st.markdown("<br>", unsafe_allow_html=True)
    m1, m2, m3, m4 = st.columns(4)
    metrics = [
        ("Total modules", len(modules)),
        ("Direct dependents", len(direct)),
        ("Indirect dependents", len(indirect)),
        ("Total impacted", len(all_impacted)),
    ]
    for col, (label, value) in zip((m1, m2, m3, m4), metrics):
        col.markdown(
            f'<div class="metric"><div class="label">{label}</div>'
            f'<div class="value">{value}</div></div>',
            unsafe_allow_html=True,
        )

# ---------------------------------------------------------------------------
# Projects
# ---------------------------------------------------------------------------
elif page == "Projects":
    st.markdown('<div class="ir-title">Projects</div>', unsafe_allow_html=True)
    st.markdown('<div class="ir-sub">Systems registered for impact analysis.</div>',
                unsafe_allow_html=True)

    for name, mods in PROJECTS.items():
        edge_count = sum(len(d) for d in mods.values())
        st.markdown(
            f'<div class="card" style="margin-bottom:14px;">'
            f'<h4>{name}</h4>'
            f'<div style="color:var(--muted);font-size:13px;">'
            f"{len(mods)} modules · {edge_count} dependencies</div></div>",
            unsafe_allow_html=True,
        )

    st.markdown("<br>", unsafe_allow_html=True)
    with st.expander("Register a new project"):
        st.text_input("Project name")
        st.text_area("Modules (one per line, format: Module: dep1, dep2)")
        st.button("Create project")

# ---------------------------------------------------------------------------
# Impact Analysis
# ---------------------------------------------------------------------------
elif page == "Impact Analysis":
    st.markdown('<div class="ir-title">Impact Analysis</div>', unsafe_allow_html=True)
    st.markdown('<div class="ir-sub">Run a focused analysis on a single module.</div>',
                unsafe_allow_html=True)

    project = st.selectbox("Project", list(PROJECTS.keys()))
    modules = PROJECTS[project]
    changed = st.selectbox("Module", list(modules.keys()))

    if st.button("Run analysis"):
        direct, indirect, all_impacted = compute_impact(modules, changed)
        level, color, ratio = assess_risk(all_impacted, len(modules))
        st.markdown(
            f"Changing **{changed}** impacts **{len(all_impacted)}** module(s) — "
            f"risk **{level}**."
        )
        st.graphviz_chart(build_dot(modules, changed, direct, indirect),
                          use_container_width=True)

# ---------------------------------------------------------------------------
# Reports
# ---------------------------------------------------------------------------
elif page == "Reports":
    st.markdown('<div class="ir-title">Reports</div>', unsafe_allow_html=True)
    st.markdown('<div class="ir-sub">Saved impact analysis runs.</div>',
                unsafe_allow_html=True)
    st.markdown(
        '<div class="card"><div style="color:var(--muted);font-size:13px;">'
        "No reports yet. Run an analysis from the Dashboard to generate one.</div></div>",
        unsafe_allow_html=True,
    )
