from assignment_service import Assignment

class Teacher:
    pass
