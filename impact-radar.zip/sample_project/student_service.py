class Student:
    pass
