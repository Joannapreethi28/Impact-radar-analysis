from student_service import Student

class Assignment:
    def __init__(self, title):
        self.title = title
