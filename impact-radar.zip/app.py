import streamlit as st

st.set_page_config(
    page_title="Impact Radar",
    layout="wide",
    initial_sidebar_state="expanded"
)

# -------------------------
# Custom Styling
# -------------------------

st.markdown("""
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

html, body, [class*="css"] {
    font-family: 'Inter', sans-serif;
}

.stApp {
    background: linear-gradient(135deg, #0f172a, #111827);
}

section[data-testid="stSidebar"] {
    background-color: #111827;
}

.block-container {
    padding-top: 2rem;
}

.title {
    font-size: 42px;
    font-weight: 700;
    color: white;
}

.subtitle {
    color: #94a3b8;
    font-size: 16px;
    margin-bottom: 25px;
}

.glass {
    background: rgba(255,255,255,0.05);
    backdrop-filter: blur(12px);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 20px;
    padding: 20px;
    color: white;
}

.metric-number {
    font-size: 32px;
    font-weight: 700;
}

.metric-title {
    color: #94a3b8;
}

.graph-box {
    height: 450px;
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:20px;
}

</style>
""", unsafe_allow_html=True)

# -------------------------
# Sidebar
# -------------------------

st.sidebar.title("Impact Radar")

page = st.sidebar.radio(
    "Navigation",
    [
        "Dashboard",
        "Projects",
        "Impact Analysis",
        "Reports"
    ]
)

# -------------------------
# Dashboard
# -------------------------

if page == "Dashboard":

    st.markdown("""
    <div class="title">Impact Radar</div>
    <div class="subtitle">
    Enterprise Software Change Impact Analysis Platform
    </div>
    """, unsafe_allow_html=True)

    c1, c2, c3, c4 = st.columns(4)

    with c1:
        st.markdown("""
        <div class="glass">
        <div class="metric-title">Projects</div>
        <div class="metric-number">12</div>
        </div>
        """, unsafe_allow_html=True)

    with c2:
        st.markdown("""
        <div class="glass">
        <div class="metric-title">Modules</div>
        <div class="metric-number">84</div>
        </div>
        """, unsafe_allow_html=True)

    with c3:
        st.markdown("""
        <div class="glass">
        <div class="metric-title">Dependencies</div>
        <div class="metric-number">142</div>
        </div>
        """, unsafe_allow_html=True)

    with c4:
        st.markdown("""
        <div class="glass">
        <div class="metric-title">Risk Alerts</div>
        <div class="metric-number">6</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    left, right = st.columns([3,1])

    with left:

        st.markdown("""
        <div class="glass">
        <h3>Impact Analysis</h3>
        </div>
        """, unsafe_allow_html=True)

        st.selectbox(
            "Project",
            [
                "Student Enrollment System",
                "Hospital Management System",
                "Library Management System"
            ]
        )

        st.selectbox(
            "Changed Module",
            [
                "Student Module",
                "Teacher Module",
                "Assignment Module"
            ]
        )

        st.button("Analyze Impact", use_container_width=True)

        st.markdown("<br>", unsafe_allow_html=True)

        st.markdown("""
        <div class="glass graph-box">
        Dependency Graph Visualization Area
        </div>
        """, unsafe_allow_html=True)

    with right:

        st.markdown("""
        <div class="glass">
        <h3>Risk Assessment</h3>
        <hr>
        <h1 style="color:#ef4444;">HIGH</h1>
        <p>Impacted Modules: 2</p>
        <p>Direct Dependencies: 1</p>
        <p>Indirect Dependencies: 1</p>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)

        st.markdown("""
        <div class="glass">
        <h3>Affected Modules</h3>
        <hr>
        <p>Assignment Module</p>
        <p>Report Module</p>
        </div>
        """, unsafe_allow_html=True)

# -------------------------
# Projects
# -------------------------

elif page == "Projects":

    st.title("Projects")

    project_name = st.text_input("Project Name")

    description = st.text_area("Description")

    st.button("Create Project")

# -------------------------
# Impact Analysis
# -------------------------

elif page == "Impact Analysis":

    st.title("Impact Analysis")

    st.selectbox(
        "Project",
        [
            "Student Enrollment System"
        ]
    )

    st.selectbox(
        "Module",
        [
            "Student Module",
            "Teacher Module",
            "Assignment Module"
        ]
    )

    st.button("Run Analysis")

# -------------------------
# Reports
# -------------------------

elif page == "Reports":

    st.title("Reports")

    st.info("Generated impact analysis reports will appear here.")
