from game.board import Board

board = Board()

print("BOARD")
board.display_board()

while True:
    number = int(input("\nEnter a number to mark: "))

    board.mark_number(number)

    print("\nMARKED MATRIX")
    board.display_marked()

    completed = board.count_completed_lines()

    print("\nCompleted Lines:", completed)
    print("Letters:", board.get_bingo_letters())

    if board.get_bingo_letters() == "BINGO":
        print("\nBINGO! You win!")
        break
