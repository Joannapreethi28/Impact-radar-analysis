from game.player import Player

player = Player("Joanna")

print("Player:", player.name)

print("\nBoard:")
player.board.display_board()

print("\nCompleted Lines:")
print(player.get_completed_lines())

print("\nLetters:")
print(player.get_bingo_letters())
