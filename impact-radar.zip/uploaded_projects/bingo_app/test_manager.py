from game.game_manager import GameManager

manager = GameManager()

manager.create_room("ABC123")

room = manager.get_room("ABC123")

print(room.room_code)

room.add_player("Joanna")
room.add_player("Alex")

print(room.get_player("Alex").name)
