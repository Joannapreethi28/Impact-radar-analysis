import streamlit as st
import pandas as pd
import websocket
import json
from streamlit_autorefresh import st_autorefresh

st.set_page_config(page_title="Multiplayer Bingo")
st.title("Multiplayer Bingo")

ROOM_CODE = "room1"
WS_URL = f"ws://127.0.0.1:8000/ws/{ROOM_CODE}"


# -----------------------------
# SESSION STATE
# -----------------------------

if "connected" not in st.session_state:
    st.session_state.connected = False

if "ws" not in st.session_state:
    st.session_state.ws = None

if "player_name" not in st.session_state:
    st.session_state.player_name = ""

if "board" not in st.session_state:
    st.session_state.board = None

if "marked" not in st.session_state:
    st.session_state.marked = None

if "called_numbers" not in st.session_state:
    st.session_state.called_numbers = []

if "scoreboard" not in st.session_state:
    st.session_state.scoreboard = []

if "current_turn" not in st.session_state:
    st.session_state.current_turn = None

if "winner" not in st.session_state:
    st.session_state.winner = None


# -----------------------------
# FUNCTIONS
# -----------------------------

def wait_for_event(ws, wanted_events):
    while True:
        response = json.loads(ws.recv())

        if response["event"] in wanted_events:
            return response


def update_from_response(response):
    if "called_numbers" in response:
        st.session_state.called_numbers = response["called_numbers"]

    if "scoreboard" in response:
        st.session_state.scoreboard = response["scoreboard"]

    if "current_turn" in response:
        st.session_state.current_turn = response["current_turn"]

    if "winner" in response:
        st.session_state.winner = response["winner"]

    if "boards" in response:
        name = st.session_state.player_name

        if name in response["boards"]:
            st.session_state.board = response["boards"][name]["board"]
            st.session_state.marked = response["boards"][name]["marked"]


def display_marked_board(board, marked):
    display_board = []

    for i in range(5):
        row = []

        for j in range(5):
            value = board[i][j]

            if marked[i][j]:
                row.append(f"{value} ✅")
            else:
                row.append(str(value))

        display_board.append(row)

    df = pd.DataFrame(display_board)
    st.dataframe(df, hide_index=True)


def auto_receive_updates():
    if st.session_state.connected and st.session_state.ws is not None:
        st.session_state.ws.settimeout(0.1)

        try:
            while True:
                response = json.loads(st.session_state.ws.recv())
                update_from_response(response)
        except:
            pass

        st.session_state.ws.settimeout(None)


# -----------------------------
# AUTO REFRESH
# -----------------------------

if st.session_state.connected:
    st_autorefresh(interval=3000, key="game_refresh")
    auto_receive_updates()


# -----------------------------
# JOIN ROOM
# -----------------------------

if not st.session_state.connected:
    st.subheader("Join Room")

    player_name = st.text_input("Enter Player Name")

    if st.button("Join Room"):
        if player_name.strip() == "":
            st.error("Please enter your name")
        else:
            ws = websocket.WebSocket()
            ws.connect(WS_URL)

            join_message = {
                "event": "join",
                "player_name": player_name
            }

            ws.send(json.dumps(join_message))

            response = wait_for_event(ws, ["your_board", "error", "room_full"])

            if response["event"] == "your_board":
                st.session_state.ws = ws
                st.session_state.connected = True
                st.session_state.player_name = player_name
                st.session_state.board = response["board"]
                st.session_state.marked = response["marked"]

                st.success(f"{player_name} joined room {ROOM_CODE}")
                st.rerun()

            else:
                st.error(response["message"])


# -----------------------------
# GAME SCREEN
# -----------------------------

if st.session_state.connected:
    st.subheader(f"Player: {st.session_state.player_name}")

    if st.session_state.winner:
        st.success(f"{st.session_state.winner} WINS!")

    st.divider()

    st.subheader("Game Status")

    if st.session_state.current_turn:
        st.write(f"Current Turn: {st.session_state.current_turn}")

    if st.session_state.called_numbers:
        st.write("Called Numbers:")
        st.write(st.session_state.called_numbers)
    else:
        st.info("No numbers called yet")

    st.divider()

    st.subheader("Your Board")

    if st.session_state.board is not None:
        display_marked_board(
            st.session_state.board,
            st.session_state.marked
        )

    st.divider()

    st.subheader("Call Number")

    number = st.number_input(
        "Enter number to call",
        min_value=1,
        max_value=25,
        step=1
    )

    if st.button("Call Number"):
        if st.session_state.current_turn != st.session_state.player_name:
            st.error("Wait for your turn")
        else:
            call_message = {
                "event": "call_number",
                "player_name": st.session_state.player_name,
                "number": int(number)
            }

            st.session_state.ws.send(json.dumps(call_message))

            response = wait_for_event(
                st.session_state.ws,
                ["number_called", "error"]
            )

            update_from_response(response)

            if response["event"] == "error":
                st.error(response["message"])
            else:
                st.success(f"Number {response['number']} called")

            st.rerun()

    st.divider()

    st.subheader("Scoreboard")

    if st.session_state.scoreboard:
        st.table(pd.DataFrame(st.session_state.scoreboard))
    else:
        st.info("Scoreboard will appear after the game starts")
