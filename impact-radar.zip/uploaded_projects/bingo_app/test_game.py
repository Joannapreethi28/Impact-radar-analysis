from game.bingo_game import BingoGame

game = BingoGame("ABC123")

game.add_player("Joanna")
game.add_player("Alex")

print("Room:", game.room_code)

print("Current Turn:")
print(game.get_current_player().name)

number = int(
    input(
        f"Enter a number from "
        f"{game.get_current_player().name}'s board: "
    )
)

success, message = game.call_number(
    game.get_current_player().name,
    number
)

print(success)
print(message)

print("\nCalled Numbers:")
print(game.called_numbers)

print("\nNext Turn:")
print(game.get_current_player().name)
