from game.bingo_game import BingoGame

game = BingoGame()

game.add_player("Joanna")

player = game.players[0]

for row in range(5):
    player.board.mark_row(row)

game.show_scoreboard()

winner = game.get_winner()

if winner:
    print(f"\nWinner: {winner.name}")
else:
    print("\nNo winner yet")
