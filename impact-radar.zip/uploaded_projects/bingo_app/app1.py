import streamlit as st
import websocket
import json
from streamlit_autorefresh import st_autorefresh

st.set_page_config(
    page_title="Multiplayer Bingo",
    page_icon="🎯",
    layout="wide"
)

ROOM_CODE = "room1"
WS_URL = f"ws://127.0.0.1:8000/ws/{ROOM_CODE}"


# -----------------------------
# CSS
# -----------------------------

st.markdown(
    """
    <style>
    .main-title {
        text-align: center;
        font-size: 45px;
        font-weight: 800;
        color: #6C63FF;
    }

    .subtitle {
        text-align: center;
        font-size: 18px;
        color: #777;
        margin-bottom: 30px;
    }

    .status-card, .small-card, .player-card {
        background: white;
        padding: 18px;
        border-radius: 16px;
        border: 1px solid #e8e8e8;
        box-shadow: 0 3px 10px rgba(0,0,0,0.08);
        text-align: center;
        margin-bottom: 12px;
    }

    .join-card {
        background: linear-gradient(135deg, #6C63FF, #8E7CFF);
        padding: 25px;
        border-radius: 18px;
        color: white;
        text-align: center;
    }

    .winner-box {
        background: linear-gradient(135deg, #FFD700, #FFA500);
        padding: 25px;
        border-radius: 20px;
        text-align: center;
        color: #222;
        font-size: 30px;
        font-weight: 800;
        margin-bottom: 20px;
    }

    .bingo-cell {
        height: 62px;
        border-radius: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 23px;
        font-weight: 800;
        border: 2px solid #e0e0e0;
        background: white;
        box-shadow: 0 2px 6px rgba(0,0,0,0.08);
    }

    .marked-cell {
        background: linear-gradient(135deg, #00C853, #64DD17);
        color: white;
        border: 2px solid #00C853;
        text-decoration: line-through;
    }

    .turn-alert {
        background: #E8F5E9;
        color: #1B5E20;
        padding: 14px;
        border-radius: 12px;
        font-weight: 700;
        text-align: center;
        margin-bottom: 15px;
    }

    .wait-alert {
        background: #FFF3E0;
        color: #E65100;
        padding: 14px;
        border-radius: 12px;
        font-weight: 700;
        text-align: center;
        margin-bottom: 15px;
    }

    .letter-row {
        display: flex;
        justify-content: center;
        gap: 8px;
        margin-top: 8px;
        margin-bottom: 8px;
    }

    .letter-done {
        width: 38px;
        height: 38px;
        border-radius: 50%;
        background: #00C853;
        color: white;
        font-weight: 800;
        display: flex;
        align-items: center;
        justify-content: center;
        text-decoration: line-through;
    }

    .letter-pending {
        width: 38px;
        height: 38px;
        border-radius: 50%;
        background: #eeeeee;
        color: #777;
        font-weight: 800;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    </style>
    """,
    unsafe_allow_html=True
)


# -----------------------------
# SESSION STATE
# -----------------------------

defaults = {
    "connected": False,
    "ws": None,
    "player_name": "",
    "board": None,
    "marked": None,
    "called_numbers": [],
    "scoreboard": [],
    "current_turn": None,
    "winner": None
}

for key, value in defaults.items():
    if key not in st.session_state:
        st.session_state[key] = value


# -----------------------------
# FUNCTIONS
# -----------------------------

def wait_for_event(ws, wanted_events):
    while True:
        response = json.loads(ws.recv())
        if response["event"] in wanted_events:
            return response


def update_from_response(response):
    if "called_numbers" in response:
        st.session_state.called_numbers = response["called_numbers"]

    if "scoreboard" in response:
        st.session_state.scoreboard = response["scoreboard"]

    if "current_turn" in response:
        st.session_state.current_turn = response["current_turn"]

    if "winner" in response:
        st.session_state.winner = response["winner"]

    if "boards" in response:
        name = st.session_state.player_name

        if name in response["boards"]:
            st.session_state.board = response["boards"][name]["board"]
            st.session_state.marked = response["boards"][name]["marked"]


def auto_receive_updates():
    if st.session_state.connected and st.session_state.ws is not None:
        st.session_state.ws.settimeout(0.1)

        try:
            while True:
                response = json.loads(st.session_state.ws.recv())
                update_from_response(response)
        except:
            pass

        st.session_state.ws.settimeout(None)


def render_board(board, marked):
    for i in range(5):
        cols = st.columns(5)

        for j in range(5):
            number = board[i][j]

            if marked[i][j]:
                cell_class = "bingo-cell marked-cell"
            else:
                cell_class = "bingo-cell"

            cols[j].markdown(
                f"""
                <div class="{cell_class}">
                    {number}
                </div>
                """,
                unsafe_allow_html=True
            )


def render_called_numbers():
    if not st.session_state.called_numbers:
        st.info("No numbers called yet")
        return

    nums = " ".join([f"`{num}`" for num in st.session_state.called_numbers])
    st.markdown(nums)


def render_bingo_letters(letters):
    bingo = "BINGO"
    completed_count = len(letters)

    html = '<div class="letter-row">'

    for index, letter in enumerate(bingo):
        if index < completed_count:
            html += f'<div class="letter-done">{letter}</div>'
        else:
            html += f'<div class="letter-pending">{letter}</div>'

    html += "</div>"

    st.markdown(html, unsafe_allow_html=True)


def render_scoreboard():
    if not st.session_state.scoreboard:
        st.info("Scoreboard will appear after the game starts")
        return

    for player in st.session_state.scoreboard:
        name = player["name"]
        letters = player["letters"]
        lines = player["lines"]

        st.markdown(
            f"""
            <div class="player-card">
                <h4>{name}</h4>
                <p><b>Completed Lines:</b> {lines}</p>
            </div>
            """,
            unsafe_allow_html=True
        )

        render_bingo_letters(letters)


# -----------------------------
# AUTO REFRESH
# -----------------------------

if st.session_state.connected:
    st_autorefresh(interval=3000, key="game_refresh")
    auto_receive_updates()


# -----------------------------
# HEADER
# -----------------------------

st.markdown(
    """
    <div class="main-title">Multiplayer Bingo</div>
    <div class="subtitle">Real-time 2–4 Player Bingo Game</div>
    """,
    unsafe_allow_html=True
)


# -----------------------------
# JOIN SCREEN
# -----------------------------

if not st.session_state.connected:
    left, middle, right = st.columns([1, 1.4, 1])

    with middle:
        st.markdown(
            """
            <div class="join-card">
                <h2>Join Game Room</h2>
                <p>Enter your player name to start playing</p>
            </div>
            """,
            unsafe_allow_html=True
        )

        st.write("")

        player_name = st.text_input(
            "Player Name",
            placeholder="Example: joanna"
        )

        if st.button("Join Room", use_container_width=True):
            if player_name.strip() == "":
                st.error("Please enter your name")
            else:
                ws = websocket.WebSocket()
                ws.connect(WS_URL)

                join_message = {
                    "event": "join",
                    "player_name": player_name
                }

                ws.send(json.dumps(join_message))

                response = wait_for_event(
                    ws,
                    ["your_board", "error", "room_full"]
                )

                if response["event"] == "your_board":
                    st.session_state.ws = ws
                    st.session_state.connected = True
                    st.session_state.player_name = player_name
                    st.session_state.board = response["board"]
                    st.session_state.marked = response["marked"]

                    st.success(f"{player_name} joined room {ROOM_CODE}")
                    st.rerun()
                else:
                    st.error(response["message"])


# -----------------------------
# GAME SCREEN
# -----------------------------

if st.session_state.connected:
    if st.session_state.winner:
        st.markdown(
            f"""
            <div class="winner-box">
                Winner: {st.session_state.winner}
            </div>
            """,
            unsafe_allow_html=True
        )

    top1, top2, top3 = st.columns(3)

    with top1:
        st.markdown(
            f"""
            <div class="small-card">
                <h3>Player</h3>
                <h2>{st.session_state.player_name}</h2>
            </div>
            """,
            unsafe_allow_html=True
        )

    with top2:
        current = st.session_state.current_turn or "Waiting"
        st.markdown(
            f"""
            <div class="small-card">
                <h3>Current Turn</h3>
                <h2>{current}</h2>
            </div>
            """,
            unsafe_allow_html=True
        )

    with top3:
        count = len(st.session_state.called_numbers)
        st.markdown(
            f"""
            <div class="small-card">
                <h3>Called</h3>
                <h2>{count} Numbers</h2>
            </div>
            """,
            unsafe_allow_html=True
        )

    left_col, right_col = st.columns([2, 1])

    with left_col:
        st.subheader("Your Bingo Board")

        if st.session_state.current_turn == st.session_state.player_name:
            st.markdown(
                """
                <div class="turn-alert">
                    Your turn! Call a number from your board.
                </div>
                """,
                unsafe_allow_html=True
            )
        else:
            st.markdown(
                """
                <div class="wait-alert">
                    Please wait for your turn.
                </div>
                """,
                unsafe_allow_html=True
            )

        if st.session_state.board is not None:
            render_board(st.session_state.board, st.session_state.marked)

        st.write("")
        st.subheader("Call Number")

        number = st.number_input(
            "Choose a number",
            min_value=1,
            max_value=25,
            step=1
        )

        call_disabled = (
            st.session_state.winner is not None
            or st.session_state.current_turn != st.session_state.player_name
        )

        if st.button(
            "Call Number",
            use_container_width=True,
            disabled=call_disabled
        ):
            call_message = {
                "event": "call_number",
                "player_name": st.session_state.player_name,
                "number": int(number)
            }

            st.session_state.ws.send(json.dumps(call_message))

            response = wait_for_event(
                st.session_state.ws,
                ["number_called", "error"]
            )

            update_from_response(response)

            if response["event"] == "error":
                st.error(response["message"])
            else:
                st.success(f"Number {response['number']} called")

            st.rerun()

    with right_col:
        st.subheader("Called Numbers")
        render_called_numbers()

        st.divider()

        st.subheader("Scoreboard")
        render_scoreboard()
