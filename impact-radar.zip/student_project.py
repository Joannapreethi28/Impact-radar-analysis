student_modules = {
    "student_service": [],
    "teacher_service": [],
    "assignments_service": [
        "student_service",
        "teacher_service"
    ],
    "delete_service": [
        "student_service",
        "assignments_service"
    ],
    "report_service": [
        "assignments_service"
    ]
}
